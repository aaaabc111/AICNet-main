for len in 96 192 336 720
do
  python -u TSLANet_Forecasting.py \
  --root_path D:/TSLANet-main/Forecasting/data/ETT-small \
  --pred_len $len \
  --data ETTh2 \
  --data_path ETTh2.csv \
  --seq_len 336 \
  --emb_dim 64 \
  --depth 1 \
  --batch_size 512 \
  --dropout 0.5 \
  --patch_size 32 \
  --train_epochs 20 \
  --pretrain_epochs 10
  #--ASB False
done