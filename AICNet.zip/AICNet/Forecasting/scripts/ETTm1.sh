for len in 96 192 336 720
do
  python -u TSLANet_Forecasting.py \
  --root_path D:/TSLANet-main/Forecasting/data/ETT-small \
  --pred_len $len \
  --data ETTm1 \
  --data_path ETTm1.csv \
  --seq_len 336 \
  --emb_dim 64 \
  --depth 2 \
  --batch_size 512 \
  --dropout 0.5 \
  --patch_size 8 \
  --train_epochs 20 \
  --pretrain_epochs 10
done